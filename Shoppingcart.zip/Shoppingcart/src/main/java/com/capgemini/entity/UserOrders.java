package com.capgemini.entity;

import java.io.Serializable;
import java.util.ArrayList;
import java.util.List;

import javax.persistence.CascadeType;
import javax.persistence.Column;
import javax.persistence.Entity;
import javax.persistence.FetchType;
import javax.persistence.GeneratedValue;
import javax.persistence.GenerationType;
import javax.persistence.Id;
import javax.persistence.JoinColumn;
import javax.persistence.JoinColumns;
import javax.persistence.JoinTable;
import javax.persistence.ManyToMany;
import javax.persistence.ManyToOne;
import javax.persistence.OneToMany;
import javax.persistence.OneToOne;
import javax.persistence.Table;

import com.fasterxml.jackson.annotation.JsonIgnore;
import com.fasterxml.jackson.databind.annotation.JsonSerialize;

@Entity(name = "JoinTableUser")
@Table(name="orders")
public class UserOrders implements Serializable{

	
	/**
	 * 
	 */
	private static final long serialVersionUID = 1L;

	@Id
	@GeneratedValue(strategy=GenerationType.AUTO)
	@Column(name="orderId")
	private Integer orderId;
	
	private String name;
	
	private Integer quantity;
	
	private Integer price;
	
	//@Column(name="userId")
	//private Long userId;
	
	@ManyToOne
	@JsonIgnore
	//@JoinColumn(name="id")
	private User usersData;
	
	
	private String orderedId;
	
	
	private boolean status;
	
	public User getUsersData() {
		return usersData;
	}
	public void setUsersData(User usersData) {
		this.usersData = usersData;
	}
	public Integer getOrderId() {
		return orderId;
	}
	public void setOrderId(Integer orderId) {
		this.orderId = orderId;
	}
	public String getName() {
		return name;
	}
	public void setName(String name) {
		this.name = name;
	}
	public Integer getQuantity() {
		return quantity;
	}
	public void setQuantity(Integer quantity) {
		this.quantity = quantity;
	}
	public Integer getPrice() {
		return price;
	}
	public void setPrice(Integer price) {
		this.price = price;
	}
	
	
	
	public String getOrderedId() {
		return orderedId;
	}
	public void setOrderedId(String orderedId) {
		this.orderedId = orderedId;
	}
	
	public boolean isStatus() {
		return status;
	}
	public void setStatus(boolean status) {
		this.status = status;
	}
	@Override
	public String toString() {
		return "UserOrders [orderId=" + orderId + ", name=" + name + ", quantity=" + quantity + ", price=" + price
				+ ", usersData=" + usersData + ", orderedId=" + orderedId + ", status=" + status + "]";
	}
	
	
	
	
	
	
	
	
	
	
}
