package com.capgemini.entity;

import javax.persistence.Column;
import javax.persistence.Entity;
import javax.persistence.GeneratedValue;
import javax.persistence.GenerationType;
import javax.persistence.Id;
import javax.persistence.Table;

import lombok.Data;

@Entity
@Table(name= "tbl_products")
@Data
public class ProductsDomain {

	@Id
    @GeneratedValue(strategy= GenerationType.IDENTITY)   
	@Column (name="pid")
    private int id;
    
    @Column(name = "pname")
    private String name;
    
    @Column(name = "pmodel")
    private String model;
    
    @Column(name = "price")
    private double price;
  
    
    @Column(name = "image") 
    private String imageUrl;
    
    @Column(name = "original_price")
    private double originalprice;
    
    @Column(name = "description")
    private String description;
    
    
    @Column(name = "offer")
    private String offer;

	

	public int getId() {
		return id;
	}

	public void setId(int id) {
		this.id = id;
	}

	public String getName() {
		return name;
	}

	public void setName(String name) {
		this.name = name;
	}

	public String getModel() {
		return model;
	}

	public void setModel(String model) {
		this.model = model;
	}

	public double getPrice() {
		return price;
	}

	public void setPrice(double price) {
		this.price = price;
	}

	

	public String getDescription() {
		return description;
	}

	public void setDescription(String description) {
		this.description = description;
	}

	public String getImageUrl() {
		return imageUrl;
	}

	public void setImageUrl(String imageUrl) {
		this.imageUrl = imageUrl;
	}

	public double getOriginalprice() {
		return originalprice;
	}

	public void setOriginalprice(double originalprice) {
		this.originalprice = originalprice;
	}

	public String getOffer() {
		return offer;
	}

	public void setOffer(String offer) {
		this.offer = offer;
	}



	
    
    //List<String> errormessage ;
    
    

}
