package com.capgemini.controller;

import java.util.ArrayList;
import java.util.Collections;
import java.util.List;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.http.HttpStatus;
import org.springframework.http.MediaType;
import org.springframework.http.ResponseEntity;
import org.springframework.web.bind.annotation.CrossOrigin;
import org.springframework.web.bind.annotation.GetMapping;
import org.springframework.web.bind.annotation.PathVariable;
import org.springframework.web.bind.annotation.PostMapping;
import org.springframework.web.bind.annotation.RequestBody;
import org.springframework.web.bind.annotation.RequestMapping;
import org.springframework.web.bind.annotation.RestController;

import com.capgemini.entity.Payments;
import com.capgemini.entity.User;
import com.capgemini.entity.UserOrders;
import com.capgemini.entity.UserPaymentCardDetails;
import com.capgemini.service.UserService;
import com.fasterxml.jackson.annotation.JsonValue;
import com.fasterxml.jackson.databind.JsonSerializable;
import com.fasterxml.jackson.databind.annotation.JsonSerialize;

@CrossOrigin("http://localhost:4200")
@RestController
public class UserController {
	
	@Autowired
	private UserService userService;

	@GetMapping("/userdetails/{email}")
	public User getUserDetials(@PathVariable("email") String email) {
		return userService.findOne(email);
	}
	
	@PostMapping("/register")
	public User registerUserDetails(@RequestBody User user) {
		System.out.println("Reg controller");
		return userService.save(user);
	}
	
	@GetMapping("/paymentsactivity/{id}")
	public List<Payments> paymentsDetails(@PathVariable("id") String paymentId) throws Exception {
		List<Payments> paymentsList = userService.userPayments(paymentId);
		
		return paymentsList;
	}
	
	
	@GetMapping("/allpayments")
	public ResponseEntity<List<Payments>> getAllpaymentsDetails() throws Exception{
		List<Payments> paymentsList = userService.alluserPayments();
				
    	return new ResponseEntity<List<Payments>>(paymentsList,HttpStatus.OK);
			
	}
	
	
	@PostMapping("/paymentsprocess")
	
	public String addPaymentDetails(@RequestBody Payments payments) throws Exception {	 
		return userService.savePayments(payments);
	}
	
	
   @PostMapping("/cardpaymentsprocess")
  
	public Payments checkPaymentDetails(@RequestBody UserPaymentCardDetails card) throws Exception {	 
		return userService.cardPayments(card);
	}
   
   

}
