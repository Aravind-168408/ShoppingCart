package com.capgemini.controller;

import java.util.HashMap;
import java.util.List;
import java.util.Map;
import java.util.Optional;

import javax.sound.sampled.ReverbType;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.data.repository.query.Param;
import org.springframework.http.HttpStatus;
import org.springframework.http.ResponseEntity;
import org.springframework.web.bind.annotation.GetMapping;
import org.springframework.web.bind.annotation.PathVariable;
import org.springframework.web.bind.annotation.PostMapping;
import org.springframework.web.bind.annotation.PutMapping;
import org.springframework.web.bind.annotation.RequestBody;
import org.springframework.web.bind.annotation.RequestMapping;
import org.springframework.web.bind.annotation.RestController;

import com.capgemini.entity.User;
import com.capgemini.entity.UserOrders;
import com.capgemini.repository.OrdersRepository;
import com.capgemini.repository.Userrepository;

@RestController
@RequestMapping("/api")
public class OrderController {
	
	@Autowired
	private Userrepository repo;
	
	@Autowired
	private OrdersRepository orderepo;
	
/**********************************************************   Get Order Details By Using User Id*****************************************************/	
	@GetMapping("/orderList/{id}")
	public ResponseEntity<?> getOrderDetails(@PathVariable Long id){	
		User user = repo.findByUserId(id);
		return new ResponseEntity<>(user,HttpStatus.OK);
 	}
/**********************************************************   Get All Order Details*****************************************************/	
	@GetMapping("/allorderslist")
	public ResponseEntity<?> getAllOrderDetails(){	
		List<User> userOrderList = repo.findAll();
		return new ResponseEntity<>(userOrderList,HttpStatus.OK);
 	}
/**********************************************************   Get Order Details By Using Id*****************************************************/		
		
		@GetMapping("/orders/{id}")
		public ResponseEntity<?> getOrderDeetailsList(@PathVariable Integer id){
			Optional<UserOrders> orderList = orderepo.findById(id);
			return new ResponseEntity<>(orderList,HttpStatus.OK);
	 	}
		
/**********************************************************   Add Orders By Using User Id  ************************************************************/
		@PutMapping("/addOrdersByUser")
		public Object addOrders(@RequestBody User user){
				
			
			User userData = repo.findByUserId(user.getId());
			System.out.println(userData.getId());
			
			if(user.getId().equals(userData.getId())&&user.getId()!=null) {
				
			User uV = new User();
			/*uV.setName(user.getName());
			uV.setPhone(user.getPhone());
			uV.setEmail(user.getEmail());
			uV.setAddress(user.getAddress());
			uV.setPassword(user.getPassword());
			uV.setRole(user.getRole());
			uV.setActive(user.isActive());
			repo.save(uV);*/
			uV.setId(user.getId());
		    Integer i = user.getId().intValue();
		    for(UserOrders uo:user.getOrdersList()) {
		    	  
		    	   uo.setOrderedId(String.valueOf(Integer.reverse(i)).substring(1));
		    	   uo.setStatus(true);
		    	   uo.setUsersData(uV);		    	     
		          }
		   orderepo.saveAll(user.getOrdersList());
			//List<User> userList = repo.getAllValuesById();
			}
			
		   return repo.findById(user.getId()); 
		}
		
		
}

