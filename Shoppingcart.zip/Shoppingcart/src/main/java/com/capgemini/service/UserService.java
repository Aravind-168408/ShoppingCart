package com.capgemini.service;

import java.util.List;

import com.capgemini.entity.Payments;
import com.capgemini.entity.User;
import com.capgemini.entity.UserOrders;
import com.capgemini.entity.UserPaymentCardDetails;

public interface UserService {

	User save(User user);
	
	User findOne(String email);

	List<Payments> userPayments(String paymentId) throws Exception;

	String savePayments(Payments payments) throws Exception;

	List<Payments> alluserPayments() throws Exception;

	Payments cardPayments(UserPaymentCardDetails card) throws Exception;

	
}
