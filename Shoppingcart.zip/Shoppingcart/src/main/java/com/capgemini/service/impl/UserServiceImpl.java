package com.capgemini.service.impl;

import java.sql.Timestamp;
import java.time.LocalDateTime;
import java.time.format.DateTimeFormatter;
import java.util.ArrayList;
import java.util.Arrays;
import java.util.Collection;
import java.util.Collections;
import java.util.Date;
import java.util.List;
import java.util.Optional;
import java.util.UUID;
import java.util.stream.Collectors;
import java.util.stream.Stream;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Service;
import org.springframework.transaction.annotation.Transactional;
import org.springframework.web.bind.annotation.RequestBody;

import com.capgemini.entity.Payments;
import com.capgemini.entity.User;
import com.capgemini.entity.UserOrders;
import com.capgemini.entity.UserPaymentCardDetails;
import com.capgemini.repository.OrdersRepository;
import com.capgemini.repository.PaymentsCardRepo;
import com.capgemini.repository.PaymentsRepo;
import com.capgemini.repository.Userrepository;
import com.capgemini.service.UserService;

@Service
public class UserServiceImpl implements UserService{

	@Autowired
	private Userrepository userRepository;
	
	
	@Autowired
	private PaymentsRepo paymentsRepo;
	
	@Autowired
	private PaymentsCardRepo paymentsCardRepo;
	
	
	@Autowired
	private OrdersRepository ordersRepository;
	
	
	
	private Payments pay =new Payments();
	@Override
	public User findOne(String email) {
		// TODO Auto-generated method stub
		return userRepository.findByEmail(email);
	}
	
	@Override
	@Transactional
	public User save(User user) {
    //register
      
       // savedUser.setOrdersList(user.getOrdersList());
      userRepository.save(user);
       //ordersRepository.saveAll(user.getOrdersList());
       //UserOrders orders = new UserOrders();
     List<UserOrders>  orders = new ArrayList<UserOrders>();
     
       for(UserOrders u:user.getOrdersList()) {
    	   u.setUsersData(user);
    	   orders.add(u);
    	   ordersRepository.saveAll(orders);
       }
      
      // orders.setPrice();
       
      List<User> savedUserList =  userRepository.findAllByEmail(user.getEmail());
     // System.out.println(savedUserList.size());
      //savedUserList.stream().filter(x->x.getEmail().equals(user.getEmail()));
    User savedUser = new User();
    UserOrders ord = new UserOrders();
      //System.out.println(savedUser);
      for(User u:savedUserList) {
    	  if(user.getEmail().equals(u.getEmail())) {
    	  savedUser.setId(u.getId());
    	  savedUser.setName(u.getName());
    	  savedUser.setEmail(u.getEmail());
    	  savedUser.setAddress(u.getAddress());
    	  savedUser.setPhone(u.getPhone());
    	 
    	  for(UserOrders v:u.getOrdersList()) {
    		  if(user.getId()==v.getUsersData().getId()) {
    		  ord.setName(v.getName());
    		  ord.setOrderId(v.getOrderId());
    		  ord.setPrice(v.getPrice());
    		  ord.setQuantity(v.getQuantity());
    		  
    		  
    		  savedUser.getOrdersList().add(ord);
    		  }
    	  }
    	  }
      }
      
         
       
       
       return savedUser;
    }

	@Override
	public List<Payments> userPayments(String paymentId)throws Exception {
		ArrayList<Payments> paymentsList = new ArrayList<Payments>();
		
			try {
				if(!paymentId.isEmpty()) 
				  {
					  Integer payId = Integer.valueOf(paymentId);
					  Payments paymentData = paymentsRepo.findByPaymentId(payId);
					  
					  if(paymentData!=null)
					  {
						  paymentsList.add(paymentData);			   
					  }
					  else {
						  throw new Exception("Payment Id Not Found");  
					  }
				  }
					 
				return paymentsList; 		
			}
			catch (Exception e) {
				throw new Exception("Enter Correct Payment Id");
			}
			
			
			 	
	}
	
	
	
	@Override
	public List<Payments> alluserPayments() throws Exception {
		
		ArrayList<Payments> paymentsList = new ArrayList<Payments>();
		try {
			paymentsList = (ArrayList<Payments>) paymentsRepo.findAll();
			return paymentsList;
		}
		catch(Exception e) {
			throw new Exception("Payment Id cannot be Empty"); 
			
		}
		
		
	}

	@Override
	public String savePayments(Payments payments) throws Exception {
		
		Payments paymentsData = new Payments();
		//UserPaymentCardDetails userPaymentCardDetails = new UserPaymentCardDetails();
		
		//List<UserPaymentCardDetails> userPaymentCardDetailsList = paymentsCardRepo.findAll();
		//System.out.println(userPaymentCardDetailsList);
		
		try {
			if(payments.getUserId()!=null&&payments.getAmount()!=null&&payments.getAmount()!=null&&payments.getPaymentType()!=null&&payments.getProductInfo()!=null) {
			paymentsData.setUserId(payments.getUserId());
			paymentsData.setAmount(payments.getAmount());
			paymentsData.setPaymentType(payments.getPaymentType());
			paymentsData.setProductInfo(payments.getProductInfo());
			paymentsData.setFirstName(payments.getFirstName());
			paymentsData.setLastName(payments.getLastName());
			Timestamp transId = new Timestamp(System.currentTimeMillis());
			String tranactionId = Long.toString(transId.getTime());
			paymentsData.setTxnId(tranactionId);
			DateTimeFormatter datetimeformat = DateTimeFormatter.ofPattern("dd-MM-yyyy HH:mm:ss a");
			LocalDateTime now = LocalDateTime.now();	  
			paymentsData.setPaymentDate(datetimeformat.format(now));	
			paymentsRepo.save(paymentsData);	
			
			
			
			
			}
			else {
				throw new Exception("Enter All The Details Properly");
			}
		    pay = paymentsRepo.findByPaymentId(paymentsData.getPaymentId());
			
		       return "Payment ID: "+pay.getPaymentId()+"\nTransaction Id: "+pay.getTxnId();
		       }
	
			
			
		 catch (Exception e) {
			System.out.println("Exception :"+e);
			throw new Exception("Enter All The Details");
		}
		
		
		
		
		
	}

	@Override
	public Payments cardPayments(UserPaymentCardDetails card) throws Exception {
		
        
		
		UserPaymentCardDetails userPaymentCardDetails  = paymentsCardRepo.findByCardNumber(card.getCardNumber());
		
		
		try {
			if(userPaymentCardDetails.getUserID().equalsIgnoreCase(card.getUserID())&&userPaymentCardDetails.getNameonCard().equalsIgnoreCase(card.getNameonCard())
					&&userPaymentCardDetails.getExpMonth()==(card.getExpMonth())
							&&userPaymentCardDetails.getExpYear().equals(card.getExpYear())
							&&userPaymentCardDetails.getcVV().equals(card.getcVV())
					
					){
				Payments payments = new Payments();
				payments.setFirstName(card.getFirstName());
				payments.setLastName(card.getLastName());
				payments.setUserId(Integer.valueOf((card.getUserID())));
				payments.setAmount("2000");
				payments.setPaymentType("Card");
				payments.setProductInfo("Electronics");
				
				String cs = savePayments(payments);
				if(cs!=null) {
					System.out.println("Payment SucessFull");
				}
				else {
					System.err.println("Payment Failed");
				}
				//Payments pay = paymentsRepo.findByPaymentId(payments.getPaymentId());
	             return pay;
			}
			else {
				throw new Exception("Enter All The Details Properly");
			}
			
			
		} catch (Exception e) {
			return null;
		}
				
	}


	
}
