package com.capgemini.repository;

import java.util.List;
import java.util.Optional;

import org.springframework.data.jpa.repository.JpaRepository;
import org.springframework.data.jpa.repository.Query;
import org.springframework.stereotype.Repository;

import com.capgemini.entity.User;
import com.capgemini.entity.UserOrders;
@Repository
public interface OrdersRepository extends JpaRepository<UserOrders, Integer>{

	UserOrders findByOrderId(Integer orderId);

	
	@Query(value = "SELECT v.name,v.order_id,v.price,v.quantity,v.users_data_id FROM orders v WHERE v.name='Camera'", nativeQuery = true)
	List<UserOrders> findByUserId(long l);

	

	//List<UserOrders> findAll(Long id); WHERE u.id = ?1

	
	

	
}
