package com.capgemini.repository;

import java.util.List;

import org.springframework.data.jpa.repository.JpaRepository;
import org.springframework.data.jpa.repository.Modifying;
import org.springframework.data.jpa.repository.Query;

import com.capgemini.entity.User;

public interface Userrepository extends JpaRepository<User, String>{

	User findByEmail(String email);

	List<User> findAllByEmail(String email);

	
  // @Query("select u from shoppingdb.user u where u.id = ?1")
   //@Query("SELECT v FROM User v WHERE v.visitType='NEW'")
	Object findById(long l);

	@Modifying
	@Query(value = "SELECT id,name,active,address,email,phone,password,role FROM User v WHERE v.id=228", nativeQuery = true)
	List<User> getAllValuesById();

	
	@Query(value = "SELECT id,name,active,address,email,phone,password,role FROM User v WHERE v.id = ?1", nativeQuery = true)
	User findByUserId(long l);
	
	
	@Query(value = "SELECT id,name,active,address,email,phone,password,role FROM User v WHERE v.id = ?1", nativeQuery = true)
	List<User> findAllById(Long id);

	

	
	
}
