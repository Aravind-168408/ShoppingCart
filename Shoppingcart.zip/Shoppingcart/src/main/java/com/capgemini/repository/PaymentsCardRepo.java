package com.capgemini.repository;

import org.springframework.data.jpa.repository.JpaRepository;
import org.springframework.data.jpa.repository.Query;
import org.springframework.stereotype.Repository;

import com.capgemini.entity.UserPaymentCardDetails;

@Repository
public interface PaymentsCardRepo extends JpaRepository<UserPaymentCardDetails, Integer>{

	
	
	
	//@Query("select p from paymentscarddata p where p.card_number like %?1")
	UserPaymentCardDetails findByCardNumber(String cardNumber);

}
